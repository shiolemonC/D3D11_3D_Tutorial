/*==============================================================================

   Direct3D̏֘A [direct3d.h]
														 Author : Youhei Sato
														 Date   : 2025/05/12
--------------------------------------------------------------------------------

==============================================================================*/
#ifndef DIRECT3D_H
#define DIRECT3D_H


#include <Windows.h>
#include <d3d11.h>


// Z[t[X}N
#define SAFE_RELEASE(o) if (o) { (o)->Release(); o = NULL; }


bool Direct3D_Initialize(HWND hWnd); // Direct3D̏
void Direct3D_Finalize(); // Direct3D̏I

void Direct3D_Clear(); // obNobt@̃NA
void Direct3D_Present(); // obNobt@̕\

// obNobt@̑傫̎擾
unsigned int Direct3D_GetBackBufferWidth(); // 
unsigned int Direct3D_GetBackBufferHeight(); // 

// Direct3DfoCX̎擾
ID3D11Device* Direct3D_GetDevice();

// Direct3DfoCXReLXg̎擾
ID3D11DeviceContext* Direct3D_GetContext();

// uhݒ֐
void Direct3D_SetAlphaBlendTransparent(); // ߏ
void Direct3D_SetAlphaBlendAdd();         // Z

//[xobt@̐ݒ
void Direct3D_SetDepthEnable(bool enable);
// Depth test ON, depth write OFF (recommended for transparent particles)
void Direct3D_SetDepthTestNoWrite();
#endif // DIRECT3D_H
