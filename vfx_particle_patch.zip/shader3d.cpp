/*==============================================================================

   VF[_[ [shader.cpp]
														 Author : Youhei Sato
														 Date   : 2025/05/15
--------------------------------------------------------------------------------

==============================================================================*/
#include <d3d11.h>
#include <DirectXMath.h>
#include <fstream>

#include "direct3d.h"
#include "debug_ostream.h"
#include "shader.h"
#include "shader3d.h"
#include "sampler.h"
using namespace DirectX;


static ID3D11VertexShader* g_pVertexShader = nullptr;
static ID3D11InputLayout* g_pInputLayout = nullptr;
static ID3D11Buffer* g_pVSConstantBuffer0 = nullptr; // 萔obt@b0
static ID3D11Buffer* g_pVSConstantBuffer1 = nullptr; // 萔obt@b1
static ID3D11Buffer* g_pVSConstantBuffer2 = nullptr; // 萔obt@b2

static ID3D11PixelShader* g_pPixelShader = nullptr;
static ID3D11Buffer* g_pPSConstantBuffer0 = nullptr; // 萔obt@b0

// ӁIŊOݒ肳́BReleasesvB
static ID3D11Device* g_pDevice = nullptr;
static ID3D11DeviceContext* g_pContext = nullptr;

static bool g_isShadowPass = false;


bool Shader3d_Initialize(ID3D11Device* pDevice, ID3D11DeviceContext* pContext)
{
	HRESULT hr; // ߂li[p

	// foCXƃfoCXReLXg̃`FbN
	if (!pDevice || !pContext) {
		hal::dout << "Shader_Initialize() : ^ꂽfoCXReLXgsł" << std::endl;
		return false;
	}

	// foCXƃfoCXReLXg̕ۑ
	g_pDevice = pDevice;
	g_pContext = pContext;


	// ORpCςݒ_VF[_[̓ǂݍ
	std::ifstream ifs_vs("shader_vertex_3d.cso", std::ios::binary);

	if (!ifs_vs) {
		MessageBox(nullptr, "_VF[_[̓ǂݍ݂Ɏs܂\n\nshader_vertex_2d.cso", "G[", MB_OK);
		return false;
	}

	// t@CTCY擾
	ifs_vs.seekg(0, std::ios::end); // t@C|C^𖖔Ɉړ
	std::streamsize filesize = ifs_vs.tellg(); // t@C|C^̈ʒu擾i܂t@CTCYj
	ifs_vs.seekg(0, std::ios::beg); // t@C|C^擪ɖ߂

	// oCif[^i[邽߂̃obt@m
	unsigned char* vsbinary_pointer = new unsigned char[filesize];

	ifs_vs.read((char*)vsbinary_pointer, filesize); // oCif[^ǂݍ
	ifs_vs.close(); // t@C

	// _VF[_[̍쐬
	hr = g_pDevice->CreateVertexShader(vsbinary_pointer, filesize, nullptr, &g_pVertexShader);

	if (FAILED(hr)) {
		hal::dout << "Shader_Initialize() : _VF[_[̍쐬Ɏs܂" << std::endl;
		delete[] vsbinary_pointer; // [NȂ悤ɃoCif[^̃obt@
		return false;
	}


	// _CAEg̒`
	// UV̕TEXCOORDƂO߂Ă
	D3D11_INPUT_ELEMENT_DESC layout[] = {
		{ "POSITION",    0, DXGI_FORMAT_R32G32B32_FLOAT,    0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "NORMAL",      0, DXGI_FORMAT_R32G32B32_FLOAT,    0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "COLOR",       0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
		{ "TEXCOORD",    0, DXGI_FORMAT_R32G32_FLOAT,       0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	};

	UINT num_elements = ARRAYSIZE(layout); // z̗vf擾

	// _CAEg̍쐬
	hr = g_pDevice->CreateInputLayout(layout, num_elements, vsbinary_pointer, filesize, &g_pInputLayout);

	delete[] vsbinary_pointer; // oCif[^̃obt@

	if (FAILED(hr)) {
		hal::dout << "Shader_Initialize() : _CAEg̍쐬Ɏs܂" << std::endl;
		return false;
	}


	// _VF[_[p萔obt@̍쐬
	D3D11_BUFFER_DESC buffer_desc{};
	buffer_desc.ByteWidth = sizeof(XMFLOAT4X4); // obt@̃TCY
	buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER; // oChtO

	g_pDevice->CreateBuffer(&buffer_desc, nullptr, &g_pVSConstantBuffer0);
	g_pDevice->CreateBuffer(&buffer_desc, nullptr, &g_pVSConstantBuffer1);
	g_pDevice->CreateBuffer(&buffer_desc, nullptr, &g_pVSConstantBuffer2);

	// ORpCς݃sNZVF[_[̓ǂݍ
	std::ifstream ifs_ps("shader_pixel_3d.cso", std::ios::binary);
	if (!ifs_ps) {
		MessageBox(nullptr, "sNZVF[_[̓ǂݍ݂Ɏs܂\n\nshader_pixel_2d.cso", "G[", MB_OK);
		return false;
	}

	ifs_ps.seekg(0, std::ios::end);
	filesize = ifs_ps.tellg();
	ifs_ps.seekg(0, std::ios::beg);

	unsigned char* psbinary_pointer = new unsigned char[filesize];
	ifs_ps.read((char*)psbinary_pointer, filesize);
	ifs_ps.close();

	// sNZVF[_[̍쐬
	hr = g_pDevice->CreatePixelShader(psbinary_pointer, filesize, nullptr, &g_pPixelShader);

	delete[] psbinary_pointer; // oCif[^̃obt@

	if (FAILED(hr)) {
		hal::dout << "Shader_Initialize() : sNZVF[_[̍쐬Ɏs܂" << std::endl;
		return false;
	}

	// pixelp萔obt@̍쐬
	//D3D11_BUFFER_DESC buffer_desc{};
	buffer_desc.ByteWidth = sizeof(XMFLOAT4); // obt@̃TCY
	//buffer_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER; // oChtO

	g_pDevice->CreateBuffer(&buffer_desc, nullptr, &g_pPSConstantBuffer0);


	return true;
}

void Shader3d_Finalize()
{
	SAFE_RELEASE(g_pPixelShader);
	SAFE_RELEASE(g_pPSConstantBuffer0);
	SAFE_RELEASE(g_pVSConstantBuffer2);
	SAFE_RELEASE(g_pVSConstantBuffer1);
	SAFE_RELEASE(g_pVSConstantBuffer0);
	SAFE_RELEASE(g_pInputLayout);
	SAFE_RELEASE(g_pVertexShader);
}

void Shader3d_SetWorldMatrix(const DirectX::XMMATRIX& matrix)
{// 萔obt@i[ps̍\̂`
	XMFLOAT4X4 transpose;

	// s]uĒ萔obt@i[psɕϊ
	XMStoreFloat4x4(&transpose, XMMatrixTranspose(matrix));

	// 萔obt@ɍsZbg
	g_pContext->UpdateSubresource(g_pVSConstantBuffer0, 0, nullptr, &transpose, 0, 0);
}

void Shader3d_SetViewMatrix(const DirectX::XMMATRIX& matrix)
{
	XMFLOAT4X4 transpose;

	// s]uĒ萔obt@i[psɕϊ
	XMStoreFloat4x4(&transpose, XMMatrixTranspose(matrix));

	// 萔obt@ɍsZbg
	g_pContext->UpdateSubresource(g_pVSConstantBuffer1, 0, nullptr, &transpose, 0, 0);
}


void Shader3d_SetProjectionMatrix(const DirectX::XMMATRIX& matrix)
{
	// 萔obt@i[ps̍\̂`
	XMFLOAT4X4 transpose;

	// s]uĒ萔obt@i[psɕϊ
	XMStoreFloat4x4(&transpose, XMMatrixTranspose(matrix));

	// 萔obt@ɍsZbg
	g_pContext->UpdateSubresource(g_pVSConstantBuffer2, 0, nullptr, &transpose, 0, 0);
}

void Shader3d_SetColor(const DirectX::XMFLOAT4& color)
{
	// 萔obt@ɍsZbg
	g_pContext->UpdateSubresource(g_pPSConstantBuffer0, 0, nullptr, &color, 0, 0);
}

void Shader3d_Begin()
{
	// _VF[_[ƃsNZVF[_[`pCvCɐݒ
	g_pContext->VSSetShader(g_pVertexShader, nullptr, 0);
	//g_pContext->PSSetShader(g_pPixelShader, nullptr, 0);
	g_pContext->PSSetShader(g_isShadowPass ? nullptr : g_pPixelShader, nullptr, 0);


	// _CAEg`pCvCɐݒ
	g_pContext->IASetInputLayout(g_pInputLayout);

	// 萔obt@`pCvCɐݒ
	g_pContext->VSSetConstantBuffers(0, 1, &g_pVSConstantBuffer0);
	g_pContext->VSSetConstantBuffers(1, 1, &g_pVSConstantBuffer1);
	g_pContext->VSSetConstantBuffers(2, 1, &g_pVSConstantBuffer2);

	g_pContext->PSSetConstantBuffers(0, 1, &g_pPSConstantBuffer0);
	// Tv[Xe[g`pCvCɐݒ
	//g_pContext->PSSetSamplers(0, 1, &g_pSamplerState);
	//Sampler_SetFillterAnisotropic();
}

bool Shader3d_IsShadowPass()
{
	return g_isShadowPass;
}

void Shader3d_SetShadowPass(bool enable)
{
	g_isShadowPass = enable;
}
